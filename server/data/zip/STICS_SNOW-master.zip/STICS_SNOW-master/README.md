# STICS_SNOW
Snow process in STICS model
