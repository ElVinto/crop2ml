#ifndef _SnowRate_
#define _SnowRate_
#define _USE_MATH_DEFINES
#include <cmath>
#include <iostream>
# include<vector>
# include<string>
using namespace std;
class SnowRate
{
    private:
    public:
        SnowRate();

};
#endif