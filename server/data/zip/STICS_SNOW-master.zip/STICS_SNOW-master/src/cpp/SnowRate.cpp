#include "SnowRate.h"
SnowRate::SnowRate() { }