import  java.io.*;
import  java.util.*;

public class SnowRate
{
    
    public SnowRate() { }
    
    public SnowRate(SnowRate toCopy, boolean copyAll) // copy constructor 
    {
        if (copyAll)
        {
        }
    }
}