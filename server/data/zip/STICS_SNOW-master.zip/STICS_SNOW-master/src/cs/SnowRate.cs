using System;
using System.Collections.Generic;

public class SnowRate
{
    
    public SnowRate() { }
    
    
    public SnowRate(SnowRate toCopy, bool copyAll) // copy constructor 
    {
    if (copyAll)
    {
    
    }
    }
}